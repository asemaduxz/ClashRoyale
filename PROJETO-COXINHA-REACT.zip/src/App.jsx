import { useEffect, useState } from 'react' 
import './App.css'

function App() { 
    const [quantidadeCoxinhas, mudarValorDeCoxinhas] = useState(0)
    const [quantidadeDePontosPorClique, mudarQuantidadeDePontosPorClique] = useState(1)
    const [custoPorClique, mudarCustoPorClique] = useState(10)
    const [custoAutomatico, mudarCustoAutomatico] = useState(20)
    const [quantidadeDePontosPorSegundo, mudarQuantidadeDePontosPorSegundo] = useState(0) 

    function aoClicarNaCoxinha() { 
      mudarValorDeCoxinhas(quantidadeCoxinhas + quantidadeDePontosPorClique) 
    } 

    function aoClicarNoBotaoDeUpgradeClicks() {
       if (quantidadeCoxinhas >= custoPorClique) {
        mudarValorDeCoxinhas(quantidadeCoxinhas - custoPorClique)  
        mudarQuantidadeDePontosPorClique(quantidadeDePontosPorClique + 1) 
        mudarCustoPorClique(Math.floor(custoPorClique * 1.5))  
      }
    }

    function aoClicarNoBotaoDeUpgradeAutomatico() { 
      if (quantidadeCoxinhas >= custoAutomatico) {
        mudarValorDeCoxinhas(quantidadeCoxinhas - custoAutomatico)   
        mudarQuantidadeDePontosPorSegundo(quantidadeDePontosPorSegundo + 1) 
        mudarCustoAutomatico(Math.floor(custoAutomatico * 1.5)) 
      }
    }  

    /* PEDIR PRO GPT CONSERTAR INCREMENTO AUTOMÁTICO DE CLIQUES!  */
   
    
  return (
    <>
        <h1>🍗 Restaurante de Coxinha Simulator</h1>
        <p>Coxinhas: <span id="counter">{quantidadeCoxinhas}</span></p>

        <div id="coxinhaBtn" onClick={aoClicarNaCoxinha}>🍗</div>

        <div className="store">
          <h2>Lojinha de Upgrades</h2>
          <button id="upgradeClick" onClick={aoClicarNoBotaoDeUpgradeClicks}>{`+1 por clique (Custa ${custoPorClique})`}</button>
          <button id="upgradeAuto" onClick={aoClicarNoBotaoDeUpgradeAutomatico}>{`+1 por segundo (Custa ${custoAutomatico})`}</button>
        </div>
    </>
  )
}

export default App
